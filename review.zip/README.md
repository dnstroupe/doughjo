# Doughjo

Big flavor. Main character energy.

An independent anime inspired donut shop concept by David Stroupe. Includes 14 fictional flavors, an original mascot, a visual box builder, a flavor finder, and demo guest checkout.

## Review

Private demo: https://doughjo.offbeatpanels.chatgpt.site
Figma: https://www.figma.com/design/f9n1CMONofo5jwtLrnkwse

## Run

Requires Python 3 and Node.js. No dependency installation needed.

```sh
npm start
npm test
```

Open http://localhost:8022

## Try it

Build a box of six or twelve. Select a slot to move, swap, or remove its donut. Duplicate flavors are allowed. The footer contains unavailable flavor and failed order scenarios. Use sample contact details. No payment or order is sent.

## Package

Source is in dist. Automated checks are in tests. See REVIEW.md for evidence, DECISIONS.md for tradeoffs, and TEST-PLAN.md for participant tasks. The Figma flow is editable and linked; the browser demo implements dynamic behavior.

## Limits

A portfolio concept, not a live restaurant. All recipes, prices, tax, allergens, pickup details, and inventory are fictional. No participant research or formal Section 508 conformance evaluation has been completed. No affiliation with anime creators is implied.

Doughshi artwork was created for this concept. The 14 donut flavors and three drinks use original concept artwork, shared across the menu, details, and box. Doughshi appears as a guide, progress companion, and celebration. These are illustrative recipes, not photographs of real products. DM Sans uses the included SIL Open Font License. Display typography uses the system Impact family with fallback. Figma uses Anton for its editable display headings and adapted Simple Design System button instances.
